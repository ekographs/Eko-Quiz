<?php
    
    include('common.php'); 
	
    
    showHeader("Register"); // calling header function 
    Navigation(); // calling navigation function
?>

<div class="container">
          <div id="Register">
          <div class="registerbox">
            <h1>Register Here</h1>
            <form>
                <p id="n">Name</p>
                <input type="name" id="FnameInput" required/>
                <p id ="u">Username</p>
                <input name="fname" type="username" id="UnameInput" maxlength="6" required/>
                <p id = "p">Password</p>
                <input type="password" id="PasswordInput" required/>
                <p id = "e">Email</p>
                <input type="email" id="EmailInput" required/>
                <button class="btnr" onclick="storeUser(event)">
                    Sign Up here
                    </button> <br>
                <p id="Result"></p>
                <a href="login.php">Have an account already?</a>
            </form>
 
          </div>
        </div>
        
       
    </div>

    <div>
        <p id = "error"></p>
        <p id = "userVad"></p>
        <p id = "passVad"></p>
        <p id = "emailVad"></p>
        <p id = "emptyVad"></p>
        </div>
<script src="register.js"></script>
<?php

    showFooter(); // calling footer function
?>