<?php
    
    include('common.php'); 
	
   
    showHeader("Game"); // calling header function 
    Navigation(); // calling navigation function
?>

<div class="container">
         <div id="Game" class="flex-center flex-column">
            <div id="dis">
                <div id="dis-item">
                  <p id="levelText" class="dis-prefix">
                    Question
                  <br></p>
                 <div id="levelBar">
                   <div id="levelfull"></div>
                 </div>
                </div>
                <div id="dis-item">
                  <p class="dis-prefix">
                    Rank
                  <br></p>
                  <h1 class="dis-main-text" id="rankings">
                    0
                  </h1>
                </div>
              </div>
        
    


          <h2 id="question">what is the right answer to this question?</h2>
          <div class="option-container">
            <p class="option-prefix">A</p>
            <p class="option-text" data-number="1">Option 1</p>
          </div>
          <div class="option-container">
              <p class="option-prefix">B</p>
              <p class="option-text" data-number="2">Option 2</p>
            </div>
            <div class="option-container">
                <p class="option-prefix">C</p>
                <p class="option-text" data-number="3">Option 3</p>
              </div>
              <div class="option-container">
                  <p class="option-prefix">D</p>
                  <p class="option-text" data-number="4">Option 4</p>
                </div>

        </div>
      </div>
 
 <script src="login.js"></script>
 <script src="rank.js"></script>
 <script src="game.js"></script>
<?php

    showFooter(); // calling footer function
?>