<?php
    
    include('common.php'); 
	
    
    showHeader("Rank"); // calling header function 
    Navigation(); // calling navigation function
?>

<div class="container">
           <div id="displayRank">
          

            </div>
      </div>
<script src="login.js"></script>
   <script src="game.js"></script>
   <script src="rank.js"></script>
<?php

    showFooter(); // calling footer function
?>