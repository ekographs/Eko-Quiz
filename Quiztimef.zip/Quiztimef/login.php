<?php
    
    include('common.php'); 
	
    
    showHeader("Login"); // calling header function 
    Navigation(); // calling navigation function
?>

<div class="container">
      <div id="LoginPara">
      <div class="signinbox">
        <h1>Login Here</h1>
        
          Username: <input type="text" id="usernameInput" required/><br>
          Password: <input type="password" id="passwordInput" required/><br>
            <button class="btnc" onclick="login(event)">
            Login
            </button>
           <br> <p id="loginFailure" style="color:red;"></p><br>
            <a href="register.php">Don't have an account?</a> <br> 
      </div>
    </div>
</div>

<script src="login.js"></script>
<?php
    showFooter(); // calling footer function
?>