function scoreRank(){
    var showScore = '';
// this function dislays the table details
    for (var i = 0; i < player.length; i++) {
        //var ranking = i+1;
        showScore += '<tr><td style="color: white;">'+ player[i].name + '</td><td style="color: white;">'+ player[i].point + '</td></tr>';
    }
    var tableTop = '<table class="table"><thead><tr><th scope="col">Name</th><th scope="col">High Score</th></tr></thead><tbody>';
    var tableBottom = '</tbody></table>';
    $('#displayRank').html(tableTop + showScore + tableBottom);
}

// this function compares the users data in the local storage and checks if user A score is greater than User B
function compare(a, b) {
  const pointA = parseInt(a.point);
  const pointB = parseInt(b.point);

  let comparison = 0;
  if (pointA < pointB) {
    comparison = 1;
  } else if (pointA > pointB) {
    comparison = -1;
  }
  return comparison;
}

player.sort(compare)

scoreRank();




