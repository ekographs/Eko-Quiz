$(document).ready(function(){
 var setSession = sessionStorage.getItem('isLoggedin');

//Array of pages to link to if user is not logged in
var linkNames = ["Home", "Register", "Sign In"];
var linkAddresses = ["home.php", "register.php", "login.php"];

//Array of pages to link to if user is logged in
var linkNames1 = ["Home", "Game Page", "Rank"];
var linkAddresses1 = ["home.php", "game.php", "rank.php"];
// this function hides the game and rank page from not logged in or registered users
	if(setSession == null){
    //Output navigation
    for(var x = 0; x < linkNames.length; x++){
        
        $("#getLinks").append('<li class="nav-item"><a class="nav-link"'+'href="' + linkAddresses[x] + '">' + linkNames[x] + '</a></li>');
    }
}
// this function displays the game and rank page to logged in or registered users
if(setSession != null){
     //Output navigation
     for(x = 0; x < linkNames1.length; x++){
         $("#getLinks").append('<li class="nav-item"><a class="nav-link"'+'href="' + linkAddresses1[x] + '">' + linkNames1[x] + '</a></li>');
     }
     $('#button').append("Welcome " + sessionStorage.getItem('isLoggedin') + "&nbsp <a class='btn btn-outline-warning my-2 my-sm-0' onclick='logout()'>Log Out</a>");
 }
  });

