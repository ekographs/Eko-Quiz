<?php
 // calling header function  for the css and body of the html
function showHeader($title){
    echo '<!DOCTYPE html>';
    echo '<html lang="en">';
    echo '<head>';
    echo '<meta charset="UTF-8" />';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0" />';
    echo '<meta http-equiv="X-UA-Compatible" content="ie=edge" />';
    echo '<title>' . $title . '</title>';
    echo '<link href="https://fonts.googleapis.com/css?family=Roboto+Mono&display=swap" rel="stylesheet">';
    echo '<link rel="stylesheet" href="bootstrap.css" />';
    echo '<link rel="stylesheet" href="css/app.css" />';
    echo '<link rel="stylesheet" href="css/game.css" />';
    echo '<link rel="stylesheet" href="css/register.css"/>';
    echo '<link rel="stylesheet" href="css/login.css"/>';
    echo '<link rel="stylesheet" href="css/rank.css" />';
    echo '<script  src="jquery-3.4.1.js">';
    echo '</script>';
    echo '<script src="bootstrap.js">';
    echo '</script>';
    echo '<script src="navigation.js">';
    echo '</script>';
    echo '</head>';
    echo '<body>';
}

function Navigation(){
    //Output banner and first part of navigation
    echo ' <nav class="navbar navbar-expand-lg navbar-dark bg-dark">';
    echo ' <a class="navbar-brand" style="color: rgba(255, 255, 255, 0.5); cursor: pointer; font-size: 30px; !important" href="">Eko Quiz';
    echo '</a>';
    echo '<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarText">';
    echo '<ul class="navbar-nav mr-auto" id="getLinks" style="font-size: 15px; !important">';
    echo '</ul>';
    echo '<span class="navbar-text" style="float: right;">        
                    <div id="button">  ';
    echo '</div></span>';
    echo '</nav>';
}
// calling header function the footer class 
function showFooter(){
    echo '<div class="footer">';
    echo '<div class="footer-content">';
    echo '<div class="footer-section about">';
    echo '<h2>AboutUs</h2>';
    echo '<h6>
        Eko Quiz is a game website
         conceived for the purpose of building<br>
        your mindset and increasing your knowledge. 
      </h6>';
    echo '</div>';
    echo '<div class="footer-section contact-form">';
    echo '<h2>Contact Us</h2>';
    echo '<br>';
    echo '<h6>';
    echo '<li>57146890</li>';
    echo '<li>fingerlicking@gmail.com</li>';
    echo '</h6>'; 
    echo '</div>';
    echo '</div>';
    echo '<div class="footer-bottom">
             &copy; | Designed by Ekoate O. Nwaforlor
          </div>';
    echo '</div>';
    echo '</body>';

    echo '</html>';

}
?>