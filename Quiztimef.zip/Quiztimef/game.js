const question = document.getElementById("question");
const options = Array.from(document.getElementsByClassName("option-text"));
const levelText = document.getElementById('levelText');
const rankText = document.getElementById('rankings');
const levelfull = document.getElementById('levelfull');

let currentQuestion = {};

// creating a delay for the question before it moves to the next 
let acceptingAnswers = false;
let rank = 0;
// this identifies what question you are on 
let questionCounter = 0;
// copy of the displayed questions into the array to enable the user get unique questions
let displayedQuestions =[];


// listing the different types of questions that will be stored in the array

let questions = [];

// making it possible to get questions from open source 
fetch(
    "https://opentdb.com/api.php?amount=15&category=18&difficulty=easy&type=multiple"
)
  .then(res => {
    return res.json();
  })
  .then(loadedQuestions => {
    console.log(loadedQuestions.results);
    questions = loadedQuestions.results.map(loadedQuestion => {
      const formattedQuestion = {
        question: loadedQuestion.question
      };

      const answerChoices = [...loadedQuestion.incorrect_answers];
      formattedQuestion.answer = Math.floor(Math.random() * 3) + 1;
      answerChoices.splice(
        formattedQuestion.answer - 1,
        0,
        loadedQuestion.correct_answer
      );

      answerChoices.forEach((option, index) => {
        formattedQuestion["Option" + (index + 1)] = option;
      });

      return formattedQuestion;
    });
    beginGame();
})

.catch(err => {
    console.error(err);
});



//CONSTANTS
const CORRECT_ANSWER = 10;
const MAX_QUESTIONS = 15;

// setting a default reset question for users what it simply does is to set the score to be 0 from the start.
beginGame = () => {
    questionCounter = 0;
    //rank = 0;
    // copying all the questions from the question array using three dots as spread operator
    // so it takes the array below and spread out each of items and put them in a new array 
    displayedQuestions = [...questions];
    genNewQuestion();
};

// for getting new questions and increasing the change of no repetition of questions since the Max_Question is limited to 3
// using math floor to multiply the amount of questions that are available

genNewQuestion = () => {

// if there is no question left in the array or the users available question has been answered then the game ends 


if (displayedQuestions.length === 0 || questionCounter >=MAX_QUESTIONS){
    var finalScore = rank;

    //sets high score for user
    for (var i = 0; i < player.length; i++) {
        if (sessionStorage.getItem('isLoggedin') == player[i].username) {
            if(player[i].point < finalScore){
                player[i].point = finalScore;
                break;
            }
        }
    }

    localStorage.setItem("Players", JSON.stringify(player));
    player = JSON.parse(localStorage.getItem('Players')) || [];
    player.sort(compare)
    scoreRank();
    
    // this stops the game 
    return window.location.assign("rank.php");
    }
    
    questionCounter++;
    // this displays the number of question you are on at the moment in the game page
    levelText.innerText = `Question ${questionCounter}/${MAX_QUESTIONS}`; 

    // this increases the level bar animation 
    levelfull.style.width = `${(questionCounter / MAX_QUESTIONS) * 100}%`;

    const questionIndex = Math.floor(Math.random() * displayedQuestions.length); // this simply means the data stored in the array is multi
    currentQuestion = displayedQuestions[questionIndex];
    question.innerText = currentQuestion.question;

// this is for each of the options giving a reference to it so for the Options the attributes or contents are displayed     
// basically assigning the correct option to the displayed question
    options.forEach( option => {
        const number = option.dataset['number'];
        option.innerText = currentQuestion['Option' + number];
 });

// this simply takes the question array and get rid of te old question in order not to repeat questions per session

 displayedQuestions.splice(questionIndex, 1);
 acceptingAnswers = true;
};

// this enables the storage of the users Options preferably the users answers to each question
// and after the user clicks it generates new question
options.forEach(option => {
    option.addEventListener("click", e => {  // takes the event as argument 
    if (!acceptingAnswers) return;

    acceptingAnswers = false; 
    const selectedOption = e.target; 
    const selectedAnswer = selectedOption.dataset["number"];
    console.log(selectedAnswer == currentQuestion.answer);

// making the correct and incorrect answers visible by adding animation and a new class    
    const classToApply = 
        selectedAnswer == currentQuestion.answer ? "right" : "wrong";
    if (classToApply === 'right') {
        increaseRank(CORRECT_ANSWER);
    }
    selectedOption.parentElement.classList.add(classToApply);

    setTimeout ( () => {
        selectedOption.parentElement.classList.remove(classToApply);
        genNewQuestion();
    }, 1000);
    
});
});

increaseRank = num => {
    rank += num;
    rankText.innerText = rank;    
}


