var player = JSON.parse(localStorage.getItem('Players')) || [];
var userVad = document.getElementById("userVad");/*Variables from here and below are messages to appear when 
the user enters any wrong information*/
var passVad = document.getElementById("passVad");
var emailVad = document.getElementById("emailVad");
var emptyVad = document.getElementById("emptyVad");
var error = document.getElementById("error");
var paswdCheck =  /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{4,8}$/;//To check if password has a number, a capital and small letter & a special character
var emailCheck =  /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; //To check the correct format of an email
var u = document.getElementById("u");/*Variables from here and below are for field title to change colour when 
the user enters any wrong information*/
var p = document.getElementById("p");
var e = document.getElementById("e");
var n = document.getElementById("n");


function storeUser(e){
    e.preventDefault();
    
    var usrObject = {name: document.getElementById("FnameInput").value,
    username:document.getElementById("UnameInput").value,
    password:document.getElementById("PasswordInput").value,
    email:document.getElementById("EmailInput").value,
    point:0};

       //If the username field is empty displays error message
    if(usrObject.username == "" || usrObject.password == "" || usrObject.name == "" || usrObject.email == ""){
        emptyVad.innerHTML = 'All fields are required';
        u.style.color = "red";
        p.style.color = "red";
        n.style.color = "red";
        //e.style.color = "red";   
    }
    else{
        emptyVad.innerHTML = "";
        u.style.color = "white";
        p.style.color = "white";
        n.style.color = "white";
        //e.style.color = "white"; 
    }

    if((usrObject.username !== "") && (usrObject.name !== "") && (usrObject.password.match(paswdCheck)) && (usrObject.email.match(emailCheck))){
        // stores data if all the fields are filled in correctly
    player.push(usrObject);
    localStorage.setItem('Players', JSON.stringify(player));
    alert('Please log in now');
    window.location.href = "login.php";
    }else{
        error.innerHTML = 'CHECK DETAILS!!'
    }
    
    for(let i = 0; i<player.length; i++){//Compares username value with username in localStorage, if they are the same then message displays that it has been taken
        if(usrObject.username == player[i].username){
            userVad.innerHTML = 'This username is already taken';
            u.style.color = "red";
    
        }else{
            u.style.color = "white";
            userVad.innerHTML = "";
        }
    }


    if((!usrObject.password.match(paswdCheck)) && (usrObject.password !== "")){ //Checks to see if password matches the password format
        passVad.innerHTML = 'Password must have capital and small letters, a number, a special character & length 4-8';
        p.style.color = "red";
    
    }else{
        p.style.color = "white";
        passVad.innerHTML = "";
    }

    if((!usrObject.email.match(emailCheck)) && (usrObject.email !== "")){//Checks to see if email matches the email format
        emailVad.innerHTML = 'Please enter correct email address'
        //e.style.color = "red";
    }else{
        //e.style.color = "white";
        emailVad.innerHTML =  "";
    }
    

     
    }


