$(document).ready(function(){
 var setSession = sessionStorage.getItem('isLoggedin');

//Array of pages to link to if user is not logged in
var linkNames = ["<li>Home<li>", "<li>Register<li>", "<li>Sign In<li>"];
var linkAddresses = ["home.php", "register.php", "login.php"];

//Array of pages to link to if user is logged in
var linkNames1 = ["<li>Home<li>", "<li>Game Page<li>", "<li>Rank<li>"];
var linkAddresses1 = ["home.php", "game.php", "rank.php"];

	if(setSession == null){
    //Output navigation
    for(var x = 0; x < linkNames.length; x++){
        $("#getLinks").append('<li><a '+'href="' + linkAddresses[x] + '">' + linkNames[x] + '</a></li>');
    }
}

if(setSession != null){
     //Output navigation
     for(x = 0; x < linkNames1.length; x++){
         $("#getLinks").append('<li><a '+'href="' + linkAddresses1[x] + '">' + linkNames1[x] + '</a></li>');
     }
 }
  });

