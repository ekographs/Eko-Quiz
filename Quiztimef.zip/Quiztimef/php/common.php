<?php
 // calling header function  for the css and body of the html
function showHeader($title){
    echo '<!DOCTYPE html>';
    echo '<html lang="en">';
    echo '<head>';
    echo '<meta charset="UTF-8" />';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0" />';
    echo '<meta http-equiv="X-UA-Compatible" content="ie=edge" />';
    echo '<title>' . $title . '</title>';
    echo '<link href="https://fonts.googleapis.com/css?family=Roboto+Mono&display=swap" rel="stylesheet">';
    echo '<link rel="stylesheet" href="css/app.css" />';
    echo '<link rel="stylesheet" href="css/bootstrap.css" />';
    echo '<link rel="stylesheet" href="css/game.css" />';
    echo '<link rel="stylesheet" href="css/register.css"/>';
    echo '<link rel="stylesheet" href="css/login.css"/>';
    echo '<link rel="stylesheet" href="css/rank.css" />';
    echo '<script type="text/javascript" src="jquery-3.4.1.min.js">';
    echo '</script>';
    echo '<script type="text/javascript" src="navigation.js">';
    echo '</script>';
    echo '</head>';
    echo '<body>';
}

function Navigation(){
    //Output banner and first part of navigation
    echo ' <nav>';
    echo ' <div class="logo">';
    echo '<h5>Eko Quiz</h5>';
    echo '</div>';
    echo '<ul class="nav-links" id="getLinks">';
    echo '</ul>';
    echo '</nav>';
}
// calling header function the footer class 
function showFooter(){
    echo '<div class="footer">';
    echo '<div class="footer-content">';
    echo '<div class="footer-section about">';
    echo '<h2>AboutUs</h2>';
    echo '<h6>
        Eko Quiz is a game website
         conceived for the purpose of building<br>
        your mindset and increasing your knowledge. 
      </h6>';
    echo '</div>';
    echo '<div class="footer-section contact-form">';
    echo '<h2>Contact Us</h2>';
    echo '<br>';
    echo '<h6>';
    echo '<li>57146890</li>';
    echo '<li>fingerlicking@gmail.com</li>';
    echo '</h6>'; 
    echo '</div>';
    echo '</div>';
    echo '<div class="footer-bottom">
             &copy; | Designed by Ekoate O. Nwaforlor
          </div>';
    echo '</div>';
    echo '</body>';

    echo '</html>';

}
?>