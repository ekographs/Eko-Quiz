<?php
    
    include('common.php'); 
	
 
    showHeader("Home"); // calling header function 
    Navigation(); // calling navigation function
?>

<div class="container">
      <div id="home" class="flex-center flex-column">
        <h1>Welcome to Eko Quiz</h1>
        <p class="mind">The concept is simple this is A quiz  game or  mind sport, 
            in which the players (as individuals or in teams)<br>
             attempt to answer questions correctly.<br>
             It is a game to test your knowledge about a certain subject the questions can be random too.<br>
             If you feel you are smart enough hit the play button.</p>
        
        <?php echo '<a class="btn" href="game.php">Play</a>'; ?>
        <?php echo '<a class="btn" href="rank.php">Ranks</a>'; ?>
      </div>
    </div>

<?php

    showFooter(); // calling footer function
    ?>