var player = JSON.parse(localStorage.getItem('Players')) || [];


// this function enables the user to login 
function game(){
    if(sessionStorage.getItem('isLoggedin') != null){
        window.location.href = "game.php";
    }
    else{
        alert('Please log in');
    }
}
// this function enables see their high score after playing 
function ranks(){
    if(sessionStorage.getItem('isLoggedin') != null){
        window.location.href = "rank.php";
    }
    else{
        alert('Please log in');
    }
}
// this function chechks if the user exists logs them in and takes them to home page 
function login(e) {
    e.preventDefault();
    var username = document.getElementById('usernameInput').value
    var password = document.getElementById('passwordInput').value
    if (username != "" && password != "") {
        for (var i = 0; i < player.length; i++) {
            if (username == player[i].username) {
                if (password == player[i].password) {
                    // log player in
                    //document.getElementById('message').innerHTML = "";
                    sessionStorage.setItem("isLoggedin", player[i].username);
                    window.location.href = "home.php";
                }
              else {
                    document.getElementById('loginFailure').innerHTML = "<p style='color: red;'>Incorrect username or password</p>";
              }
            }
        }
    }
    else{
        alert('All fields are required');
    }
}
// this function kills the logged in user 
function logout(){
  sessionStorage.removeItem("isLoggedin");
  window.location.href = "home.php";
}